<?php

class Feladatok_grafikon_Controller
{
	public $baseName = 'feladatok_grafikon';  //meghatározni, hogy melyik oldalon vagyunk
	public function main(array $vars) // a router által továbbított paramétereket kapja
	{

  //betöltjük a nézetet
    $view = new View_Loader($this->baseName."_main");

    
$con  = mysqli_connect("localhost","root","","web2");
 if (!$con) {
     # code...
    echo "Problem in database connection! Contact administrator!" . mysqli_error();
 }else{
         $sql ="SELECT ev,COUNT(elismeresid) as 'db' FROM kapott INNER JOIN szinesz ON szinesz.id=kapott.szineszid GROUP BY ev ORDER BY kapott.ev ASC;";
         $result = mysqli_query($con,$sql);
         $chart_data="";
         while ($row = mysqli_fetch_array($result)) { 
 
            $ev[]  = $row['ev']  ;
            $db[] = $row['db'];
        }
 
 
 }
 $view->assign('ev',$ev);
$view->assign('db',$db);
}

}

?>