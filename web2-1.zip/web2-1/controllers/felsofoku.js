function nevek() {
    $.post(
        "feladatok_ajax.php",
        {"op" : "nev"},
        function(data) {
            //$("#orszagselect").html('<option value="0">Válasszon ...</option>');
            $("<option>").val("0").text("Válasszon ...").appendTo("#nevselect");
            var lista = data.lista;
            for(i=0; i<lista.length; i++)
                //$("#orszagselect").append('<option value="'+lista[i].id+'">'+lista[i].nev+'</option>');
                $("<option>").val(lista[i].id).text(lista[i].nev).appendTo("#nevselect");
        },
        "json"                                                    
    );
};

function evek() {
    $("#evselect").html("");
    $("#elismeresselect").html("");
    $(".adat").html("");
    var nevid = $("#nevselect").val();
    if (nevid != 0) {
        $.post(
            "feladatok_ajax.php",
            {"op" : "ev", "id" : nevid},
            function(data) {
                $("#evselect").html('<option value="0">Válasszon ...</option>');
                var lista = data.lista;
                for(i=0; i<lista.length; i++)
                    $("#evselect").append('<option value="'+lista[i].id+'">'+lista[i].nev+'</option>');
            },
            "json"                                                    
        );
    }
}

function elismeresek() {
    $("#elismeresselect").html("");
    $(".adat").html("");
    var evid = $("#evselect").val();
    if (evid != 0) {
        $.post(
           "feladatok_ajax.php",
            {"op" : "elismeres", "id" : evid},
            function(data) {
                $("#elismeresselect").html('<option value="0">Válasszon ...</option>');
                var lista = data.lista;
                for(i=0; i<lista.length; i++)
                    $("#elismeresselect").append('<option value="'+lista[i].id+'">'+lista[i].nev+'</option>');
            },
            "json"                                                    
        );
    }
}

function elismeres() {
    $(".adat").html("");
    var elismeresid = $("#elismeresselect").val();
    if (elismeresid != 0) {
        $.post(
          "feladatok_ajax.php",
            {"op" : "info", "id" : elismeresid},
            function(data) {
                $("#nev").text(data.nev);
                $("#ev").text(data.ev);
                $("#elismeres").text(data.elismeres);
               
            },
            "json"                                                    
        );
    }
}

$(document).ready(function() {
   nevek();
   
   $("#nevselect").change(evek);
   $("#evselect").change(elismeresek);
   $("#elismeresselect").change(elismeres);
   
   $(".adat").hover(function() {
        $(this).css({"color" : "white", "background-color" : "black"});
    }, function() {
        $(this).css({"color" : "black", "background-color" : "white"});
    });
});