<?php

class Feladatok_restful_Controller
{
	public $baseName = 'feladatok_restful';  //meghat�rozni, hogy melyik oldalon vagyunk
	public function main(array $vars) // a router �ltal tov�bb�tott param�tereket kapja
	{

//bet�ltj�k a n�zetet
		$view = new View_Loader($this->baseName."_main");



$url = "http://localhost/web2/controllers/szerver.php";
$result = "";
if(isset($_POST['id']))
{
  // Felesleges sz�k�z�k eldob�sa
  $_POST['id'] = trim($_POST['id']);
  $_POST['csn'] = trim($_POST['csn']);
  $_POST['un'] = trim($_POST['un']);
  $_POST['bn'] = trim($_POST['bn']);
  $_POST['jel'] = trim($_POST['jel']);
  
  // Ha nincs id �s megadtak minden adatot (csal�di n�v, ut�n�v, bejelentkez�si n�v, jelsz�), akkor besz�r�s
  if($_POST['id'] == "" && $_POST['csn'] != "" && $_POST['un'] != "" && $_POST['bn'] != "" && $_POST['jel'] != "")
  {
      $data = Array("csn" => $_POST["csn"], "un" => $_POST["un"], "bn" => $_POST["bn"], "jel" => sha1($_POST["jel"]));
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha nincs id de nem adtak meg minden adatot
  elseif($_POST['id'] == "")
  {
    $result = "Hiba: Hi�nyos adatok!";
  }
  
  // Ha van id, amely >= 1, �s megadt�k legal�bb az egyik adatot (csal�di n�v, ut�n�v, bejelentkez�si n�v, jelsz�), akkor m�dos�t�s
  elseif($_POST['id'] >= 1 && ($_POST['csn'] != "" || $_POST['un'] != "" || $_POST['bn'] != "" || $_POST['jel'] != ""))
  {
      $data = Array("id" => $_POST["id"], "csn" => $_POST["csn"], "un" => $_POST["un"], "bn" => $_POST["bn"], "jel" => $_POST["jel"]);
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha van id, amely >=1, de nem adtak meg legal�bb az egyik adatot
  elseif($_POST['id'] >= 1)
  {
      $data = Array("id" => $_POST["id"]);
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha van id, de rossz az id, akkor a hiba ki�r�sa
  else
  {
    echo "Hiba: Rossz azonos�t� (Id): ".$_POST['id']."<br>";
  }
}

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$tabla = curl_exec($ch);
curl_close($ch);

$view->assign('kitabla',$tabla);
$view->assign('kiresult',$result);

	}
}


?>