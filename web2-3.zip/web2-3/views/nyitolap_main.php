
<body>

<img id="ez" src="<?php echo SITE_ROOT?>images/1.jpg" style="margin-left:5%; margin-top: 5%; width: 85%">
<!-- First Grid -->
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
      <h1>A díjról</h1>
      <h5 class="w3-padding-32">A Nemzet Színésze címet a nemzeti színjátszás élő művészei közül azok kaphatják meg, akik a magyar nyelv ápolása, a nemzeti irodalom tolmácsolása, a magyar színművészet, a nemzeti színjátszás fejlesztése, népszerűsítése során kimagasló érdemeket szereztek. A címet első ízben 2000. augusztus 22-én adták át.

A Nemzet Színésze cím annak adományozható, aki fő- vagy epizódszerepekben kimagasló teljesítményt nyújtott; betöltötte a 62. életévét; 40 évet a színészi pályán vagy legalább 20 évadot – évadonként legalább egy szerepben – a budapesti Nemzeti Színház színpadán töltött. Ezek mellett fontos kritérium, hogy legalább egy jelentős elismerése is legyen (pl. Kossuth- vagy Jászai Mari-díja). 
</h5>

      <p class="w3-text-grey">
A címet legfeljebb tizenketten viselhetik egyszerre, és ők életük végéig havonta nettó 630 ezer forint juttatásban részesülnek. Ha a cím egyik viselője elhalálozik, a megüresedett helyre a cím többi birtokosa egyhangú szavazással tehet javaslatot.

Az elismerést először Schwajda György kormánybiztos, a Nemzeti Színház Részvénytársaság vezérigazgatója javaslatára adományozta a nemzeti kulturális örökség minisztere. Legutóbb, 2021-ben Lehoczky Zsuzsának adományozták a címet.</p>
    </div>

    
  </div>
</div>

<!-- Second Grid -->
<div class="w3-row-padding w3-light-grey w3-padding-64 w3-container">
  <div class="w3-content">
    

    <div class="w3-twothird">
      <h1>2021-es év nyertese</h1>
      <img id="ez" src="<?php echo SITE_ROOT?>images/2.jpg" style="width: 80%">
      <h5 class="w3-padding-32">Lehoczky Zsuzsa Kossuth- és kétszeres Jászai Mari-díjas színművészt, érdemes és kiváló művészt választották a Nemzet Színészévé a cím jelenlegi birtokosai – tájékoztatta az MTI-t a Nemzeti Színház. Lehoczky Zsuzsát az április közepén elhunyt Törőcsik Mari helyére választották meg a nemzet színészei csaknem egyórás tanácskozás után.

A közlemény szerint a Nemzet Színészei közül Bodrogi Gyula, Haumann Péter, Király Levente, Molnár Piroska, Szacsvay László, Tordy Géza és Jordán Tamás személyesen is jelen volt a Nemzeti Színházban megtartott zárt megbeszélésen. Almási Éva, Csomós Mari, Cserhalmi György és Máthé Erzsi telefonon kapcsolódott be a választásba.</h5>

      <p class="w3-text-grey">Lehoczky Zsuzsa még gyermekként kezdte pályáját, mikor édesanyja beíratta a szegedi színházban működő balettiskolába.
Sarlós Gábor főrendező elhívta magával Kaposvárra szubrettnek, így az 1956–1957-es évadot a kaposvári színházban töltötte.
A forradalom idején tejeskocsival utazott haza Szegedre. Utána az ottani színházban játszott, több, jelentős szubrettszerepet.
1962-től a Budapesti Operettszínház tagja.</p>
    </div>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h1 class="w3-margin w3-xlarge">A Nemzet Színésze</h1>
</div>


 
 

