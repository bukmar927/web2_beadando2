<?php
try {

	$dbh = new PDO('mysql:host=localhost;dbname=web2', 'root', '',
				array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
	$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');

	$sql = "SELECT * FROM felhasznalok";     
	$sth = $dbh->query($sql);
	$rows = $sth->fetchAll(PDO::FETCH_ASSOC);
}
	catch (PDOException $e) {
	echo "Hiba: ".$e->getMessage();
}

$html  = '
<html>
	<head>
		<style>
			table {border-collapse: collapse;}
			th {font-weight: border: 1px solid red; text-align: center;}
			td {border: 1px solid blue;}
		</style>
	</head>
	<body>
		<h1 style="text-align: center; color: blue;">FELHASZNÁLÓK</h1>
		<table>
			<tr style="background-color: red; color: white;">
			<th style="width: 5%;">&nbsp;<br>&nbsp;<br>&nbsp;</th>
			<th style="width: 20%;">&nbsp;<br>CSALÁDI NÉV</th>
			<th style="width: 20%;">&nbsp;<br>UTÓNÉV</th>
			<th style="width: 20%;">&nbsp;<br>BEJELENTKEZÉS</th>
			<th style="width: 35%;">&nbsp;<br>JELSZÓ</th>
			</tr>
';
			$i=1;
foreach($rows as $row) {
	if($i)
		$html .= '
			<tr style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 255);">
		';
	else					
		$html .= '
			<tr style="background-color: rgb(0, 0, 255); color: rgb(255, 255, 255);">
		';
	$j=0;
	foreach($row as $cell) {
		if($j==0)
			$html .= '
				<td style="text-align: right; width: 5%;">
			';
		else if($j < 4)
			$html .= '
				<td style="text-align: left; width: 20%;">
			';
		else if($j == 4)
			$html .= '
				<td style="text-align: left; width: 35%;">
			';
		$html .= $cell;
		$html .= '
				</td>
		';
		$j++;
	}
	$html .= '
			</tr>
	';
	$i = !$i;
}
$html .= '
		</table>
	<body>
</html>';
echo $html;
?> 