<h1> Restful Api </h1>


<pre>
<?php
  if(isset($_POST['buttonGet'])) { 
?><pre>
<?php
 $url = "https://gorest.co.in/public-api/users?access-token=e474cf141b97ca9ef8d91d5859ebcb6a1a69887daa2ca51d745668a3dd152156";
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $tabla = curl_exec($ch);
 curl_close($ch);
 print_r(json_decode($tabla, JSON_PRETTY_PRINT));
?>
</pre>
    <?php }


   if(isset($_POST['buttonPost'])) {   
?><pre>
<?php
 $url = "https://gorest.co.in/public-api/users?access-token=e474cf141b97ca9ef8d91d5859ebcb6a1a69887daa2ca51d745668a3dd152156";
 $adatok = array(
 "first_name" => "aaa",
 "last_name" => "bbb",
 "gender" => "male",
 "email" => "proba@data.hu",
 "status" => "active"
 );
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($adatok));
 curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $tabla = curl_exec($ch);
 curl_close($ch);
 print_r(json_decode($tabla, JSON_PRETTY_PRINT));
?>
</pre>
Válasz:
Megkeresni az ID-t:
[id] => 75106
https://gorest.co.in/public-api/users/75106
A most felvitt erőforrás kiíratása:
<pre>
<?php
 $url = "https://gorest.co.in/public-api/users/75106?access-token=e474cf141b97ca9ef8d91d5859ebcb6a1a69887daa2ca51d745668a3dd152156";
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $tabla = curl_exec($ch);
 curl_close($ch);
 print_r(json_decode($tabla, JSON_PRETTY_PRINT));
?>
</pre>
<?php
}





 if(isset($_POST['buttonPut'])) {  
 	?>
<pre>
<?php
 $url = "https://gorest.co.in/public-api/users/75106?access-token=e474cf141b97ca9ef8d91d5859ebcb6a1a69887daa2ca51d745668a3dd152156";
 $adatok = array("first_name" => "ccc");
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT"); 
 curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($adatok));
 curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $tabla = curl_exec($ch);
 curl_close($ch);
 print_r(json_decode($tabla, JSON_PRETTY_PRINT));
?>
</pre>
<?php 
}


 if(isset($_POST['buttonDelete'])) { 
?>

<pre>
<?php
 $url = "https://gorest.co.in/public-api/users/75106?access-token=e474cf141b97ca9ef8d91d5859ebcb6a1a69887daa2ca51d745668a3dd152156";
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE"); 
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $tabla = curl_exec($ch);
 curl_close($ch);
 print_r(json_decode($tabla, JSON_PRETTY_PRINT));
?>
</pre>

<?php
 } 
?>

    <form method="post">
        <input type="submit" name="buttonGet"
                value="GET"/>
                  <form method="post">
        <input type="submit" name="buttonPost"
                value="POST"/>
                         <form method="post">
        <input type="submit" name="buttonPut"
                value="PUT"/>
                         <form method="post">
        <input type="submit" name="buttonDelete"
                value="DELETE"/>