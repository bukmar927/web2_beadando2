<!DOCTYPE HTML>
<html>
  <head>
  <meta charset="utf-8">
  <script type="text/javascript" src = "../controllers/jquery.min.js"></script>
  <script type="text/javascript" src = "../controllers/felsofoku.js"></script>
  <title>Felsőfokú intézmények</title>
  <style>
    #informaciosdiv {
      width: 400px;
    }
    #intezmenyinfo {
      float: right;
      border: 1px solid black;
      width: 190px;
      height: 100px;
    }
    .cimke{
      display: inline-block;
      width: 60px;
      text-align: right;
    }
    span {
      margin: 3px 5px;
    }
    label {
      display: inline-block;
      width: 70px;
      text-align: right;
    }
    select {
      width: 115px;
    }
  </style>
  </head>
  <body>
    <h1>Nemzet színészei:</h1>
    <div id = 'informaciosdiv'>
      <div id = 'intezmenyinfo'>
        <span class="cimke">Név:</span><span id="nev" class="adat"></span><br>
        <span class="cimke">Év:</span><span id="ev" class="adat"></span><br>
        <span class="cimke">Elismerés:</span><span id="elismeres" class="adat"></span><br>
      </div>
      <label for='nevcimke'>Név:</label>
      <select id = 'nevselect'></select>
      <br><br>
      <label for = 'evcimke'>Év:</label>
      <select id = 'evselect'></select>
      <br><br>
      <label for = 'elismerescimke'>Elismerés:</label>
      <select id = 'elismeresselect'></select>
    </div>
  </body>
</html>
