<?php

class Feladatok_pdf_Controller
{
	public $baseName = 'feladatok_pdf';  //meghatározni, hogy melyik oldalon vagyunk
	public function main(array $vars) // a router által továbbított paramétereket kapja
	{

  //betöltjük a nézetet
    $view = new View_Loader($this->baseName."_main");
}

}

?>